import java.util.Scanner;

public class ATM {
    private Scanner scanner;
    private BankService bankService = new BankService();
    private boolean cardInserted;
    private String currentCard;

    public ATM() {
        scanner = new Scanner(System.in);
        cardInserted = false;
    }

    public void start() {
        System.out.println("Welcome to the ATM!");
        while (true) {
            if (!cardInserted) {
                insertCard();
            } else {
                showMainMenu();
            }
        }
    }

    private void insertCard() {
        System.out.println("Please insert your ATM card.");
        String cardNumber = scanner.nextLine();

        System.out.println("Please enter your PIN:");
        String pin = scanner.nextLine();

        boolean validated = bankService.validateCard(cardNumber, pin);
        if (validated) {
            System.out.println("Card validated successfully.");
            cardInserted = true;
            currentCard = cardNumber;
        } else {
            System.out.println("Invalid card or PIN. Please try again.");
        }
    }

    private void showMainMenu() {
        System.out.println("Please select an option:");
        System.out.println("1. Withdraw");
        System.out.println("2. Deposit");
        System.out.println("3. Transfer");
        System.out.println("4. Check Balance");
        System.out.println("5. Cancel Transaction");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                withdraw();
                break;
            case 2:
                deposit();
                break;
            case 3:
                transfer();
                break;
            case 4:
                checkBalance();
                break;
            case 5:
                cancelTransaction();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
    }

    private void withdraw() {
        System.out.println("Enter the amount to withdraw (multiples of $20):");
        int amount = scanner.nextInt();

        if (amount % 20 != 0) {
            System.out.println("Invalid withdrawal amount. Amount should be in multiples of $20.");
            return;
        }

        boolean withdrawalSuccessful = bankService.withdraw(currentCard, amount);
        if (withdrawalSuccessful) {
            System.out.println("Cash withdrawal successful. Please take your cash.");
            printReceipt("Withdrawal", amount);
        } else {
            System.out.println("Insufficient funds or invalid amount. Please try again.");
        }
    }

    private void deposit() {
        System.out.println("Enter the amount to deposit:");
        int amount = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.println("Please insert the envelope containing your cash.");
        String envelope = scanner.nextLine();

        boolean depositSuccessful = bankService.deposit(currentCard, amount, envelope);
        if (depositSuccessful) {
            System.out.println("Cash deposit successful.");
            printReceipt("Deposit", amount);
        } else {
            System.out.println("Invalid deposit amount. Please try again.");
        }
    }

    private void transfer() {
        System.out.println("Enter the amount to transfer:");
        int amount = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.println("Enter the destination account number:");
        String destinationAccount = scanner.nextLine();

        boolean transferSuccessful = bankService.transfer(currentCard, amount, destinationAccount);
        if (transferSuccessful) {
            System.out.println("Transfer successful.");
            printReceipt("Transfer", amount);
        } else {
            System.out.println("Invalid transfer amount or destination account. Please try again.");
        }
    }

    private void checkBalance() {
        double balance = bankService.getBalance(currentCard);
        System.out.println("Your current balance is: $" + balance);
        printReceipt("Balance Inquiry", balance);
    }

    private void cancelTransaction() {
        cardInserted = false;
        System.out.println("Transaction canceled. Please take your card.");
    }

    private void printReceipt(String transactionType, double amount) {
        System.out.println("\nReceipt:");
        System.out.println("-------------------------------");
        System.out.println("Transaction Type: " + transactionType);
        System.out.println("Amount: $" + amount);
        System.out.println("Date: " + getCurrentDate());
        System.out.println("Time: " + getCurrentTime());
        System.out.println("-------------------------------");
    }

    private String getCurrentDate() {
        // Implement your logic to get the current date
        return "YYYY-MM-DD";
    }

    private String getCurrentTime() {
        // Implement your logic to get the current time
        return "HH:mm:ss";
    }

    public static void main(String[] args) {
        ATM atm = new ATM();
        atm.start();
    }
}


